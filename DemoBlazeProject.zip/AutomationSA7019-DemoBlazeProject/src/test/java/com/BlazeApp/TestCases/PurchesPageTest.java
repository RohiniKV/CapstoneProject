package com.BlazeApp.TestCases;

import org.testng.annotations.Test;

public class PurchesPageTest {
  @Test
  public void f() {
  }
}
