package com.BlazeApp.TestCases;

import org.testng.annotations.Test;

public class ConfirmationPageTest {
  @Test
  public void f() {
  }
}
