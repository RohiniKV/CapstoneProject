package com.BlazeApp.Pages;

public class ConfirmationPage {

}
